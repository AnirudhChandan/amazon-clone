// For Firebase JS SDK v7.20.0 and later, measurementId is optional

import firebase from "firebase/compat/app";
import "firebase/compat/auth";
import "firebase/compat/firestore";

const firebaseConfig = {
  apiKey: "AIzaSyBugo8DlI5cwvc-SB7Tei_QAPm54WqNuHY",
  authDomain: "challenge-940e1.firebaseapp.com",
  projectId: "challenge-940e1",
  storageBucket: "challenge-940e1.appspot.com",
  messagingSenderId: "206512188254",
  appId: "1:206512188254:web:b6aaf2bd644c8083457dcf",
  measurementId: "G-SP2LWV3TL8",
};

const firebaseApp = firebase.initializeApp(firebaseConfig);

const db = firebaseApp.firestore();

const auth = firebase.auth();

export { db, auth };
